A SwiftUI based Swift Playgrounds App
#  FlowinGArt
## Overview
    It's an app project to help people connect or reconnect with art. Using concepts of Generative Art such as flow fields it create an unique experience of exploration. Feel free to learn a bit about theses concepts throght popover messages, and try all the features, the results are infinity!

--- 

 
## Device:
The '*FlowinGArt*' project was created to run on iPad Pro devices.
The app creates many particle objects to promote a unique experience, so I recommend running it on a physical device for faster and smoother results.
It is optimized to run in Portrait and Landscape mode and can also be switched to dark mode :)

 ---
 
 
## Credits
* **Author:** 
        Cássio Gião Dezotti;
* **Images:** 
        made by Cássio Dezotti using free software Figma
* **Icons:** 
        some are SF Symbols from iOS system
        some made by Cássio Dezotti using free software Figma
* **Texts:** 
        made by Cássio Dezotti;
* **Fonts:** 
        Default iOS font San Francisco;
* **Art and algorithm inspiration:** *
            Tylor Hobbs - Fidenza work
* **Code references:** 
            CustomSlider from
            Source Culjo Lagos, Nigeria 
            https://stackoverflow.com/questions/62587261/swiftui-2-handle-range-slider

        Consulted and learned from, developer.apple.com, hackingwithswift.com, swiftontap.com, swiftbysundell.com, forums.swift.org, wwdcnotes.com, tylerxhobbs.com, stack overflow, github and youtube.
 
* Thanks to my friends, teachers and family who supported me and give me strengh. s2 :)

